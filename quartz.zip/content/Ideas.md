Shepherds are able to cause artificial blooming, which can buff vessels essentially, they have other charqu harmonize and help the vessels charqu and help the charqu in general. shepherds will think about granting strength which is what buffs are, their idea of strength will influence what the results of the buff are, think of cool visuals.


Shepherds will stay rare but 95% of every group will have a shepherd due to the nature of the stories progression, where the characters go and what they interact iwth and such, you find more gamers in an arcade lol


The auntie looks for amir that was the nameless boy and instead finds samir, who insists on joining her


Maybe the entire backstory niko and vivi have in the current loop are just fake, the world just wiped and niko wakes up in a desert


The priming looks like everything being marked in patterns including the sky which makes it look like fireworks, theres bells chiming during the entire duration. Based on new years eve and the general 3 pm 9 pm clocktower bells, signals of something new



Human technology and information causes the cradle to essentially overflow / overload, which causes the first priming, after it happens a few times humanity is basically extinct, one of their last resort plans being to become a part of the cradle where they could theoretically control it and send real humans to the moon where they had to survive for a few decades maybe, until they were done with the cradle, but due to devi the cradle kept on wiping and resetting itself, causing the timer to run out and even humanity on the moon to go extinct


To make Ith complete his goal of becoming human but as a human he wont have long to live, during that time human ith and niko just go on a short journey where Ith lives while knowing for sure hes human, everything feels so much more, but now he doesnt wanna die anymore, hes human and he wants to travel more, but now he has to die

Maybe Ith has a bunch of clones that helped him keep control of the world, so that humanity never completely fell to ruins, but he and his clones have lived long enough so he wants to give them escape or let them live human, he at least wants to live as a human. These clones will basically be different characters at this stage, all broken in different ways and some with different morals than others, some being insane but he isnt emotionally strong enough to stop them himself, this has caused countless cycles by his hand alone, some of these clones are the main villains

In pre human the general cycle of priming should disappear, or maybe it should just stay interpreted, but it should at least give a hope of everything having meaning

A pre pre human story or so, i was thinking about a game thats more abouth ith, the final battle is in the cradle where you fight "existence" itself and at the end it seems that you're just swinging at air, its the bad ending

Maybe the hermit is a sort of time traveling thing or so or like infinite, which is why its so simple, the idea is that its goal was to save devi for some reason throughout time, while it doesnt know which one devi is, only when its sure, so after the branched castle, does he leave the castle which has then through time completed its purpose. Its goal to save devi was part of a larger goal, probably to clear a path to a future, in this case nikhil and ith create that future and devi is necessary for nikhils motivation and their whole success

The hermit is so simple cause of how old it is, and the more it is the more pain it would be in i feel like.

Maybe a cause of the blighting is too much information in the cradle, so its like a ticking timebomb that gets defused at the end of pre-human, maybe said that its completely safe now or just gone, but then it still exists in post human to give a sense of dread to the people reading that know

Nikhil has some of iths memories cause of the bleeding

Nikhil in the end kind of follows through with his childhood dream of being a knight, as he helps the villain with his goal, putting some clones to rest and giving some hope


DRAW A STICK FIGURE IRL AND USE IT AS THE ENDING


GOAL: figure out what it means to make a better world and then do it, maybe figure out why the world isnt great for some even when understanding both tragedy and hope
-
Or same but more personal, wanting to live and figuring out what it means to live meaningfully and wanting to be remembered
-
Maybe wanting ones own space as in an area that has everything, just a great place for the people you care about, not per se isolated and perfect but just wonderful


Old person ith was the one that started plans and shit in iths country, with nikhils father being affected and basically being on the same team as old person ith, which is why patron ith killed him


Azhar should be treated as a packmule by sarah early in the story, but this disappears quickly. Azhar should be in danger with ann animal or so pretty quick due to being less mobile, but gets saved by amir, here amir should be able to really show off his strength, with azhar feelingn conflicted about amir being an unknown factor but being saved.


Amir should get hurt, chunk out of his side, wall thins and nikhil's influence grows stronger, quietly cussing and talking to himself like along the lines of "fucking hurts you know", but goes on doing what he does


Its public that nikhils father got murdered but no culprit, nikhil os annoyed how people didnt try long enough on figuring out who it was, maybe a scene where he asks the culprit "it was you, wasnt it" as hes brash and managed to figure some things out


Just murder samir, having him have his own journey where he meets and loses people, possessions and maybe even an arm, the results of a normal man that wasnt really supposed to be in the current slipping in, either breaking him mentally and dying in a similar way to Amir or him staying the 'greatest' character (cause of what he does for the trio) and dying with a smile, maybe for the trio even


Samir gives nikhil a rucksack for his journey, when on the ship he is slurred along by the siblings, sarah finds the rucksack on the ship and steals it before they exit the ship, not knowing its even Nikhils. Azhar gives her an earful cause hes gonna take the blame again, but the realization midway that theyre in a different country completely.


Maybe they plan to sleep in someone's stable who wakes them up in the morning with a pitchfork and all mad, only for nikhil to break it causing them to give up on resolving the issue and just run away instead, this is a point where nikhils power can be showcased


Sarah grabs both realizing that negotiations are over and they run towards the city and maze like streets and eventually accidentally trip over someones flower pot at the end, this being the florist who is very forgiving cause of the siblings sincerity, they explain how theyre basically on a trek and she teaches them, with mostly azhar remembering (cause hes responsible but also that the florist is pretty and hes finally interacting with someone lol)


They ask about the pretty flower they see everywhere being a Vivi something flower that means something the along the lines of great determination, enduring, wonder. Maybe sarah goes like "oh u want this one?" or "lets try it on you" and puts it on amir as a very temporary hair ornament. This is to hide that vivi is his first word and give it a natural reason and integration. The name vivi shouldnt come up anymore unti lthe end of the branched castle
They should eventually run into a field of vivi flowers at the end of the first arc so amirs first word is vivi


In the prologue sarah should be a concubine to a guy that dislikes socializing, them having met at some point and her being one of the rare people he took a liking to, also to go against tropes he should look decent at least, idea is that he looks good but seems very walled off and uninterested in things but not lacking confidence. Mainly to sell the idea that another route could have happened and that its not just destiny saving her


POST HUMAN IDEA
Imagine that eventually parallel worlds are created due to priming (i want a very controlled one maybe), then theres someone who gets sent to a parallel world (which might kill him everywhere else). Outside of his dying everywhere, this was the concept behind a game where a wife and husband were hunted down with the wife sending her husband off, he forgets her and only has basic memories that drive him, the goal of the game is to find out as many clues while navigating dangers, the clues keep your character motivated and the ending is reached once your character has no more motivation or succeeds in saving her. (kinda similar to vivi nico now that i think about it) 


Trees and such growing in between humans and spirits can have human faces


Devi should reluctantly send the trio off to Fiorinte, for the purpose of having them be marked by Ith, this is cause amir is most likely gonna interact with a lot of patrons and being marked by a patron protects you from them, they wont take the first action (most likely)


azhar loses an eye and gets a prosthetic with a charqye with abilities


Luca is marked by two patrons, by ith and another that he has an intimate relationship with


Maybe PRE HUMAN ends with a bit of fan service, u see azhars stories become plays, u see devi being popular among the people and kids and such, u see sarah with obvious wealth talking to nico (who was amir which is prince), u see even sri living a more normal life, u see them all bantering doing stuff together, you see other characters, some ruling countries even, you see short time skips, some of those countries going to war and such.
The idea is that ith in the pilot goes on about how excited he is for whats gonna happen to the world with imagery of lore and events and people that will appear in the story, ending on a title of nikhil picking dates with cold eyes and crescents. Only for it to end with ith narrating the latter part of the ending, being thankful the experiences and his life, finally dying, maybe due to old age like a human like he wanted.
-
After his death the next page is just black which acts as a signal that the story is genuinely over, only for the next page to be black, the next to be black with a bit of rain platter and the next with even more, then its a very modern bit sci fi street with a figure sitting on stairs in the center background. It zooms in and its a posthuman titlecardwith isa with his pupils instead of amirs crescent and the prehuman titlecard

Of course not every character is recurring, especially the onnes in the amir part of the story, amir grows habits from the people he meets and those surround him. When nikhil takes over fully some of these habits should just dissapear (not all), this is to add weight cause it kills the last remaining connection the story has to those characters.

Some stuff about Ith and Nikhil. Nikhil can help Ith become human, thats what ith wants and nikhil wants it so he can actually kill Ith, this is not a secret and is something hes okay with.
Maybe nikhil spares him cause Ith had his reasons for not intervening with fiorentes blighting, and also as a form of revenge against the people that forsakened his father and family in general, even if this is meant to be really selfish of him, he should still have a better reason for hating the country. Maybe he lets Ith live as hes a balancing force, maybe to counteract whatever patrons are actually actively dangerous. I think i like ith becoming human eventually though, like a rebirth

Return to fiorinte arc where theres an army crusading to kill a jormungandr esque creature, survivors and Ith. Luca also is notified by his new patron, that a mark of ith and maybe his brother is returning to fiorinte. This arc amir will be separated from the siblings and slowly be plunged into becoming nikhil who kills the owl and plans to kill ith, he becomes an anomaly this arc, this is good cause it makes the readers who just started trusting nikhil a little bit, still seem scary. Nikhil should only say "i forgive you" to luca without much emotion and "thank you for what you've done, you dont have to follow me anymore" to azhar and sarah who are upset, he then says "in that case, ill make your dreams come true" as payment, theyre not happy that it feels transactional but they accept it. Nikhil will be a bit annoyed though, he has a lot going on in his head and is trying to just make peace, it wont be very expressive though.

Details on nikhils pierce attack, if its long ranged he does the same motion as pulling a bow, pulling back his fist and stretching out his hand forward, then slamming them together, pointing the back of his hand to where he wants to aim.

Ceremonial ministers: Ox war, Owl finance, Wolf guard, elk (horns cut off cause heavy)

Blight can kinda be healed through absorbing spirits, as people that are considered blighted have too much blight, if u have too much blight u add more spirit

A patron called Raad
,maybe luca's patron selfishly wants to take amir away from Ith, so she can reunite luca and nikhil

Maybe the rival of lakshman, so the paint guy that named priming n bleeding, is still alive and antagonistic, lakshman should be dead though, it feels right to give him weight

bridges, Devi should teach azhar  the basic skill of doing this.
They are one of the rules of the world
Maybe patrons can create them, altering terrain



Devi grinning n falling with nico required, her laughing afterwards when on the ground, maybe her escaping a flying steampunk city, though could be Sri instead to have them bond as Sri is basically family to Devi instead, so they'll have to get close eventually
'
Azhar's artificial eye being able to see whats 'necessary', allowing him to see temperature, waves, xray, that kind of stuff, i'd wanna give future sight but im not confortable adding anything time based besides slowed perception looking like slowing down time, though it could be laplace's demon and predicting, though unable to predict the action of charqye and only the results and output afterwards.


The branched castle works with similar dynamics to the leyline/tunnel waypoints, but instead of one space being in two locations, its in no location, bit brainfucky and i dont understand it myself but it feels appropriate, shepherds and patrons can access it by using the same teleporting method but being in the place its supposed to be in,, those marked by the hermit can enter and exit as they please, which is only sri and devi.

Ith's growth when still a normal charqye was going towards becoming human? Maybe his goal is achieved, maybe Nikhil takes revenge after and maybe even helps him towards his goal so he can even kill him